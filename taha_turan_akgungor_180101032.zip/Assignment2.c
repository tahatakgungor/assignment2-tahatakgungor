#include <stdio.h>
#include <stdlib.h>
#define MAXC 256

int main(int argc , char *argv[])
{
   
    char buf[MAXC] = "";
    FILE *fp = fopen (argv[1], "r");

    int r,c;
    int numberofInt=0;

    int *numbersFromText;
    numbersFromText = (int*)malloc(256 * sizeof(int));

    ///////////////////////////////////////////////////

    while (fgets (buf, MAXC, fp)) {
        char *p = buf;
        int val, nchars = 0;

        while (*p) {
            if (sscanf (p, "%d%n", &val, &nchars) == 1) {
                numbersFromText[numberofInt++] = val;
            }
            p += nchars;       
            for (; *p; p++) {   
                if (*p >= '0' && *p <= '9') 
                    break;
                if (*p == '-' && *(p+1) >= '0' && *(p+1) <= '9') 
                    break;
            }
        }
    }

    fclose (fp);
    fp = fopen (argv[2], "w");

    /////////////////////////////////////////////////////////////

    r = numbersFromText[0];
    c = numbersFromText[1];

    int *maxResourceMatrix = (int*)malloc((r*c) * sizeof(int));
    int *resourceAllocationMatrix = (int*)malloc((r*c) * sizeof(int));
    int *resourceAvailable = (int*)malloc((c) * sizeof(int));

    for (int i = 2; i < numberofInt; i++)
    {
        if(i < (r*c)+2){
            maxResourceMatrix[i-2] = numbersFromText[i];
        }else if(i < (2*r*c)+2){
            int a = i - ((r*c)+2);
            resourceAllocationMatrix[a] = numbersFromText[i];
        }else{
            int b = i - ((2*r*c)+2);
            resourceAvailable[b] = numbersFromText[i];
        }
    }

    ////////////////////////////////////////////////////////////

    int *needMatrix = (int*)malloc((r*c) * sizeof(int));

    for (int i = 0; i < (r*c); i++)
    {
        needMatrix[i] = maxResourceMatrix[i] - resourceAllocationMatrix[i] ;
    }

    fprintf(fp,"Need Matrix :\n"); printf("Need Matrix :\n");
    for (int i = 0; i < r*c; i++)
    {
       fprintf(fp,"%d ", needMatrix[i]); printf("%d ", needMatrix[i]);
        if((i+1) % c == 0){
           fprintf(fp,"\n"); printf("\n");
        }
    }
    
    //////////////////////////////////////////////////////////////
    
    int *changeofResourceAvailable = (int*)malloc((r*c) * sizeof(int));
    int count = 0, counter = 0, process;
    int completed[r], safeSequence[r];

    for(int i = 0; i< r; i++)
    {
	    completed[i] = 0;
    }

    do{
        process = -1;

        for(int i = 0; i < r; i++)
        {
            if(completed[i] == 0)
            {
                process = i ;
                for(int j = 0; j < c; j++)
                {   
                    int x = (i*c)+j;
                    if(resourceAvailable[j] < needMatrix[x])
                    {
                        process = -1;
                        break;
                    }
                }
            }
            if(process != -1)
                break;
        }

        if(process != -1)
        {
            safeSequence[count] = process + 1;
            count++;
            for(int j = 0; j < c; j++)
            {
                resourceAvailable[j] += resourceAllocationMatrix[(c*process)+j];
                changeofResourceAvailable[counter++] = resourceAvailable[j];
                completed[process] = 1;
            }
        }
    }while(count != r && process != -1);

    /////////////////////////////////////////////////////////////

    if(count == r)
    {
        fprintf(fp,"Safe Sequence is :\n"); printf("Safe Sequence is :\n");
        for(int i = 0; i < r; i++)
        {
            fprintf(fp,"%c  ", (char)(safeSequence[i]+64)); printf("%c  ", (char)(safeSequence[i]+64));
        }
        
        fprintf(fp,"\nChange in available resource matrix :\n"); printf("\nChange in available resource matrix :\n");
        for (int i = 0; i < r*c; i++)
        {
            fprintf(fp,"%d ", changeofResourceAvailable[i]); printf("%d ", changeofResourceAvailable[i]);
            if((i+1) % c == 0){
               fprintf(fp,"\n"); printf("\n");
            }
        }
    }else{
	   fprintf(fp,"\nUnsafe state!"); printf("\nUnsafe state!"); }

    /////////////////////////////////////////////////////////////

    
    fclose(fp);
    return 0;

}